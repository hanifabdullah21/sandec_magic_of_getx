<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Community as C;
use Validator;

class CommunityController extends Controller
{
    public function apiNewData(Request $request)
    {
        $data = $request->only('name', 'description', 'born_date');
        $validation = Validator::make($data, C::RULE, C::RULE_MESSAGE);
        if ($validation->fails()) {
            return array(
                'success' => false,
                'message' => 'Gagal menambahkan data. '.$validation->errors()->first(),
                'result' => null
            );
        }

        $data = C::create($request->all());

        return array(
            'success' => true,
            'message' => 'Berhasil menambahkan data baru',
            'result' => $data
        );
    }

    function getAllData(){
        $data = C::get();
        return array(
            'success' => true,
            'message' => 'Berhasil mendapatkan data',
            'result' => $data
        );
    }
}
