<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Community extends Model
{
    use HasFactory;

    protected $table = "communities";

    protected $hidden = [
        'created_at',
        'updated_at'
    ];

    protected $fillable = [
        'id',
        'name',
        'description',
        'born_date'
    ];

    const RULE = [
        'name' => 'required',
        'name' => 'unique:communities'
    ];

    const RULE_MESSAGE = [
        'name.required' => 'nama tidak boleh kosong',
        'name.unique' => 'nama sudah terdaftar',
    ];
}
